package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText editTextName;
    Button btnClick;
    TextView textName;
    String result;
    private String hello = "Hello";
    private String hello1 = "hello";
    private String hi = "Hi";
    private String hi1 = "hi";

    private String hru = "How are you";
    private String hru1 = "how are you";

    private String m = "Good morning";
    private String m1 = "good morning";

    private String eve = "Good evening";
    private String eve1 = "good evening";

    private String y = "Yes";
    private String y1 = "yes";

    private String n = "No";
    private String n1 = "no";

    private String ty = "Thank you";
    private String ty1 = "thank you";

    private String wc = "You're welcome";
    private String wc1 = "you're welcome";

    private String em = "Excuse me";
    private String em1 = "excuse me";

    private String sry = "Sorry";
    private String sry1 = "I am sorry";

    private String wiyn = "What is your name?";
    private String wiyn1 = "what is your name";

    private String mni = "My name is ";
    private String mni1 = "my name is ";

    private String wdys = "What did you say";
    private String wdys1 = "what did you say";

    private String today = "Today";
    private String today1 = "today";

    private String tom = "Tomorrow";
    private String tom1 = "tomorrow";

    private String yesterday = "Yesterday";
    private String yesterday1 = "yesterday";

    private String now = "Now";
    private String now1 = "now ";

    private String before = "Before";
    private String before1 = "before";

    private String later = "Later";
    private String later1 = "later ";

    private String family = "Family";
    private String family1 = "family";

    private String one = "One";
    private String one1 = "one";

    private String two = "Two";
    private String two1 = "two";

    private String three = "Three ";
    private String three1 = "three";

    private String four = "Four ";
    private String four1 = "four";

    private String five = "Five";
    private String five1 = "five";

    private String six = "six ";
    private String six1 = "Six";


    private String seven = "Seven ";
    private String seven1 = "seven";

    private String eight = "eight";
    private String eight1 = "Eight";

    private String nine = "nine ";
    private String nine1 = "Nine";

    private String ten = "ten ";
    private String ten1 = "Ten";














    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextName =(EditText)findViewById(R.id.editTextName);

        btnClick = (Button) findViewById(R.id.btnClick);

        textName = (TextView) findViewById(R.id.textName);

        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();

                if (name.equals(hello) || name.equals(hello1) || name.equals(hi) || name.equals(hi1)) {
                    textName.setText("Kon'nichiwa \n こんにちは");


                } else if (name.equals(hru) || name.equals(hru1)) {
                    textName.setText("Ogenkidesuka \n お元気ですか");

                } else if (name.equals(m) || name.equals(m1)) {
                    textName.setText("Ohayōgozaimasu \n おはようございます");

                } else if (name.equals(eve) || name.equals(eve1)) {
                    textName.setText("Konbanwa \n こんばんは");

                } else if (name.equals(wc) || name.equals(wc1)) {
                    textName.setText("Dōitashimashite \n どういたしまして");

                } else if (name.equals(y) || name.equals(y1)) {
                    textName.setText("Hai \n はい");

                } else if (name.equals(n) || name.equals(n1)) {
                    textName.setText("Bangō \n 番号");

                } else if (name.equals(ty) || name.equals(ty1)) {
                    textName.setText("Arigatō \n ありがとう");

                } else if (name.equals(em) || name.equals(em1)) {
                    textName.setText("Sumimasen \n すみません");

                } else if (name.equals(sry) || name.equals(sry1)) {
                    textName.setText("Gomennasai \n ごめんなさい");

                } else if (name.equals(wiyn) || name.equals(wiyn1)) {
                    textName.setText("O-namae wa nan desu ka \n おなまえはなんですか");

                } else if (name.equals(mni) || name.equals(mni1)) {
                    textName.setText("Watashinonamaeha \n 私の名前は");

                } else if (name.equals(wdys) || name.equals(wdys1)) {
                    textName.setText("Nante iimashita ka \n なんていいましたか");

                } else if (name.equals(today) || name.equals(today1)) {
                    textName.setText("kyou \n 今日");

                } else if (name.equals(tom) || name.equals(tom1)) {
                    textName.setText("ashita \n 明日");

                } else if (name.equals(yesterday) || name.equals(yesterday1)) {
                    textName.setText("kinou \n 昨日");

                } else if (name.equals(now) || name.equals(now1)) {
                    textName.setText("ima \n 今");

                } else if (name.equals(before) || name.equals(before1)) {
                    textName.setText("mae ni \n 前に");

                } else if (name.equals(later) || name.equals(later1)) {
                    textName.setText("ato de \n 後で ");

                } else if (name.equals(family) || name.equals(family1)) {
                    textName.setText("kazoku \n 家族 ");

                } else if (name.equals(one) || name.equals(one1)) {
                    textName.setText("ichi \n いち ");

                } else if (name.equals(two) || name.equals(two1)) {
                    textName.setText("ni \n に");

                } else if (name.equals(three) || name.equals(three1)) {
                    textName.setText("san \n さん");

                } else if (name.equals(four) || name.equals(four1)) {
                    textName.setText("shi \n し");

                } else if (name.equals(five) || name.equals(five1)) {
                    textName.setText("go \n ご ");

                } else if (name.equals(six) || name.equals(six1)) {
                    textName.setText("roku \n ろ ");

                } else if (name.equals(seven) || name.equals(seven1)) {
                    textName.setText("nana \n なな ");


                } else if (name.equals(eight) || name.equals(eight1)) {
                    textName.setText("hachi \n はち ");

                } else if (name.equals(nine) || name.equals(nine1)) {
                    textName.setText("ku \n く");

                } else if (name.equals(ten) || name.equals(ten)) {
                    textName.setText("juu \n じゅう");
                } else {
                    textName.setText("Invalid");
                }




            }




        });






    }


}
